<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
	'dsn'	=> '',
	'hostname' => Mc_Sqlserver,
	'port' => Mc_Sqlport,
	'username' => Mc_Sqluid,
	'password' => Mc_Sqlpwd,
	'database' => Mc_Sqlname,
	'dbdriver' => Mc_Dbdriver,
	'dbprefix' => Mc_SqlPrefix,
	'pconnect' => FALSE,
	'db_debug' => TRUE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => Mc_Sqlcharset,
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$db['mccms'] = array(
	'dsn'	=> '',
	'hostname' => '127.0.0.1',
	'port' => '3306',
	'username' => 'root',
	'password' => 'root',
	'database' => 'mccms',
	'dbdriver' => 'mysqli',
	'dbprefix' => 'mc_',
	'pconnect' => FALSE,
	'db_debug' => TRUE,
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'gbk',
	'dbcollat' => 'gbk_chinese_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);