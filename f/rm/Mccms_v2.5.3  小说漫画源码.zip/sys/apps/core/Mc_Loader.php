<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mc_Loader extends CI_Loader {

	public function __construct()
	{
		parent::__construct();
		log_message('debug', "MY_Loader Class Initialized");
	}

	//网站模版
    public function get_templates($dir='')
    {
    	if(!empty($dir)){
            $this->_ci_view_paths = array(VIEWPATH.$dir.DIRECTORY_SEPARATOR => TRUE);
		}elseif(defined('IS_ADMIN')){
            $this->_ci_view_paths = array(VIEWPATH.'admin'.DIRECTORY_SEPARATOR => TRUE);
		}else{
            $this->_ci_view_paths = array(VIEWPATH.Skin_Pc_Path => TRUE);
		}
    }
}