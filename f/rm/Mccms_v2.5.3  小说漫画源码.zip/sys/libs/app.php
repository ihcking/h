<?php if (!defined('FCPATH')) exit('No direct script access allowed');
return array (
  'apikey' => '',
  'update' => 
  array (
    'android' => 
    array (
      'version' => '1.0.0',
      'downurl' => '',
      'force' => '1',
      'text' => '1.新版本发布',
    ),
    'ios' => 
    array (
      'version' => '1.0.0',
      'downurl' => '',
      'force' => '1',
      'text' => '1.新版本发布',
    ),
  ),
  'pay' => 
  array (
    'vip' => 
    array (
      0 => 
      array (
        'day' => '30',
        'rmb' => '25',
      ),
      1 => 
      array (
        'day' => '90',
        'rmb' => '60',
      ),
      2 => 
      array (
        'day' => '180',
        'rmb' => '108',
      ),
      3 => 
      array (
        'day' => '365',
        'rmb' => '198',
      ),
    ),
    'cion' => 
    array (
      0 => 
      array (
        'cion' => '100',
        'rmb' => '1',
      ),
      1 => 
      array (
        'cion' => '800',
        'rmb' => '8',
      ),
      2 => 
      array (
        'cion' => '1200',
        'rmb' => '12',
      ),
      3 => 
      array (
        'cion' => '1800',
        'rmb' => '18',
      ),
      4 => 
      array (
        'cion' => '5000',
        'rmb' => '50',
      ),
      5 => 
      array (
        'cion' => '9800',
        'rmb' => '98',
      ),
    ),
    'ticket' => 
    array (
      0 => 
      array (
        'nums' => '1',
        'rmb' => '1',
      ),
      1 => 
      array (
        'nums' => '5',
        'rmb' => '5',
      ),
      2 => 
      array (
        'nums' => '12',
        'rmb' => '12',
      ),
      3 => 
      array (
        'nums' => '18',
        'rmb' => '18',
      ),
      4 => 
      array (
        'nums' => '50',
        'rmb' => '50',
      ),
      5 => 
      array (
        'nums' => '98',
        'rmb' => '98',
      ),
    ),
  ),
  'search' => 
  array (
    0 => '斗罗大陆',
    1 => '总裁',
    2 => '逆天邪神',
    3 => '尊上',
    4 => '万界仙王',
    5 => '仙武帝尊',
    6 => '斗破苍穹',
    7 => '元尊',
    8 => '末世女友',
  ),
  'book_search' => 
  array (
    0 => '斗罗大陆',
    1 => '总裁',
    2 => '逆天邪神',
    3 => '尊上',
    4 => '万界仙王',
    5 => '仙武帝尊',
    6 => '斗破苍穹',
    7 => '元尊',
    8 => '末世女友',
  ),
  'html' => 
  array (
    'agreement' => '<p><b>用户协议</b></p><p>用户协议自行后台修改</p>',
    'privacy' => '<p><b>隐私政策</b></p><p>隐私政策自行后台修改</p>',
  ),
);