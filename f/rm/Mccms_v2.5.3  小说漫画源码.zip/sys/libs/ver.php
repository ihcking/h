<?php
/**
 * @Mccms open source management system
 * @copyright 2016-2020 mccms.cn. All rights reserved.
 * @Author:cheng kai jie
 * @Dtime:2020-01-11
 */
defined('BASEPATH') OR exit('No direct script access allowed');
define('Apiurl','Ly9hcGkuY2hzaGNtcy5uZXQvbWNjbXM');
define('Zykurl','ec6ct0j2qX/FoAmtS6z2Z4ERee0hOtwaeVo4MfM6KBUL54SwZuHN1u1xdpIITY3ZS0KX4A');
define('Zykbookurl','6766sIkDT6M9mvLMK5ZIJ6iWr0PDjXzUUZCmAzKWYXnJTe/3yXtnHwMz7Q1xKRRFA6Quyh78tag1');
define('Ver','v2.5.3');