<?php
class WPCOM_PLUGIN_PANEL{
    function __construct( $args ){
        global $_wpcom_plugins;
        if(!isset($_wpcom_plugins)) $_wpcom_plugins = array();
        $this->info = $args;
        $this->key = isset($this->info['key']) ? $this->info['key'] : '';
        $this->version = isset($this->info['ver']) ? $this->info['ver'] : '';
        $this->basename = isset($this->info['basename']) ? $this->info['basename'] : '';
        $this->plugin_slug = isset($this->info['slug']) ? $this->info['slug'] : '';
        $this->updateName = 'wpcom_update_' . $this->info['plugin_id'];
        $this->automaticCheckDone = false;
        $_wpcom_plugins[$this->info['plugin_id']] = $this->plugin_slug;
      
        //add_action( 'delete_site_transient_update_plugins', array($this, 'updated') );
        add_action( 'admin_menu', array($this, 'init'));
    }

    function init(){
        $title = isset($this->info['title']) ? $this->info['title'] : '';
        $icon = isset($this->info['icon']) ? $this->info['icon'] : '';
        $position = isset($this->info['position']) ? $this->info['position'] : '85';
        if($this->is_active()) add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));

        add_menu_page( $title, $title, 'edit_theme_options', $this->plugin_slug, array( &$this, 'options'), $icon, $position);
    }

    function options(){
        require_once WPCOM_ADMIN_PATH . 'utils.php';
        
        do_action( 'wpcom_plugin_panel_init' );
        $this->options = get_option($this->key);
        $this->form_action();
        $pages = WPCPM_ADMIN_UTILS::get_all_pages();

         // Load CSS
        wp_enqueue_style( "panel", WPCOM_ADMIN_URI . "css/panel.css", false, WPCOM_ADMIN_VERSION, "all");
        wp_enqueue_style( 'wp-color-picker' );

        // Load JS
        wp_enqueue_script("panel", WPCOM_ADMIN_URI . "js/panel.min.js", array('jquery', 'jquery-ui-core', 'wp-color-picker'), WPCOM_ADMIN_VERSION, true);
        wp_enqueue_media();

        ?>
        <div class="wrap wpcom-wrap">
            <div class="wpcom-panel-head">
                <div class="wpcom-panel-copy">WPCOM PLUGIN PANEL V<?php echo WPCOM_ADMIN_VERSION;?></div>
                <h1>插件设置<small><?php echo isset($this->info['name'])?$this->info['name']:'';?></small></h1>
            </div>
            <?php echo $this->build_form();?>
        </div>
    <?php }

    private function build_form(){
        if($this->is_active()){ ?>
            <form action="" method="post" id="wpcom-panel-form" class="wpcom-panel-form">
                <?php wp_nonce_field( $this->key . '_options', $this->key . '_nonce', true );?>
                    <?php if(isset($this->settings->option)) { $i=0;foreach ($this->settings->option as $item) {
                        $this->option_item($item, $i);
                        $i++;
                    }} ?>
                <div class="submit" style="padding-left: 25%;">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="保存更改">
                </div>
            </form>
        <?php }else{
			//安装完毕后删除开始
            $option_name  = 'wpcom_46b3ade48ebb2b3e';
			$options_data = 'NDc2OThlNGEyMzk1MTFlNzM0MzIwMzJiZTg4YjQ3ZjlleUprYjIxaGFXNGlPaUprYm1GNmFYaDFMbTVsZENJc0luWmxjbk5wYjI0aU9pSXlMak11TVNJc0ltOXdkR2x2YmlJNlczc2libUZ0WlNJNklteHBjM1JmY0dGblpTSXNJblJwZEd4bElqb2lYSFUxTWpFM1hIVTRPRFk0WEM5Y2RUaGlaVFpjZFRZd1l6VmNkVGs0TnpWY2RUazNOaklpTENKa1pYTmpJam9pWEhVM05USTRYSFUwWlRobFhIVTJOak5sWEhVM09UTmhYSFU1TldWbFhIVTVPRGs0WEhVMU1qRTNYSFU0T0RZNFhIVTFORGhqWEhVNU5XVmxYSFU1T0RrNFhIVTRZbVUyWEhVMk1HTTFYSFUzTmpnMFhIVTVPRGMxWEhVNU56WXlYSFZtWmpCalhIVTVPRGMxWEhVNU56WXlYSFU1TnpBd1hIVTRPVGd4WEhVMlpHWmlYSFUxTW1Fd1hIVTNOMlZrWEhVMFpXVXpYSFUzT0RBeFhIVm1aakZoVzFGQlVISmxjM05kSWl3aWMzUmtJam9pSWl3aWRIbHdaU0k2SW5CaFoyVWlmU3g3SW01aGJXVWlPaUp1WlhkZmNHRm5aU0lzSW5ScGRHeGxJam9pWEhVMk0yUXdYSFU1TldWbFhIVTVPRGMxWEhVNU56WXlJaXdpWkdWell5STZJbHgxTnpVeU9GeDFOR1U0WlZ4MU5tUm1ZbHgxTlRKaE1GeDFOalZpTUZ4MU9UVmxaVngxT1RnNU9GeDFOelk0TkZ4MU9UZzNOVngxT1RjMk1seDFabVl3WTF4MU9UZzNOVngxT1RjMk1seDFPVGN3TUZ4MU9EazRNVngxTm1SbVlseDFOVEpoTUZ4MU56ZGxaRngxTkdWbE0xeDFOemd3TVZ4MVptWXhZVnRSUVZCeVpYTnpMVzVsZDEwaUxDSnpkR1FpT2lJaUxDSjBlWEJsSWpvaWNHRm5aU0o5TEhzaWJtRnRaU0k2SW1OaGRHVm5iM0o1SWl3aWRHbDBiR1VpT2lKY2RUVXlNVGRjZFRnNE5qaGNkVFU1TXpSY2RUa3daVGhjZFRVeU1EWmNkVGRqTjJJaUxDSmtaWE5qSWpvaVhIVTVOV1ZsWEhVM1lqVTBYSFUxTWpFM1hIVTRPRFk0WEhVNU9EYzFYSFU1TnpZeVhIVTFPVE0wWEhVNU1HVTRYSFUyTmpObFhIVTNPVE5oWEhVM05qZzBYSFUxTWpBMlhIVTNZemRpWEhWbVpqQmpYSFUyTXpBNVhIVTVNREE1WEhVMk1tVTVYSFU1T0RkaFhIVTFaVGhtWEhVMk5qTmxYSFUzT1ROaElpd2ljM1JrSWpvaUlpd2lkSGx3WlNJNkltTmhkRjl0ZFd4MGFWOXpiM0owSWl3aWRHRjRJam9pY1dGZlkyRjBJbjBzZXlKdVlXMWxJam9pY1hWbGMzUnBiMjVmY0dWeVgzQmhaMlVpTENKMGFYUnNaU0k2SWx4MU5tSmpabHgxT1RnM05WeDFOall6WlZ4MU56a3pZVngxT1RWbFpWeDFPVGc1T0NJc0ltUmxjMk1pT2lJaUxDSnpkR1FpT2lJeU1DSXNJblI1Y0dVaU9pSjBaWGgwSW4wc2V5SnVZVzFsSWpvaVlXNXpkMlZ5YzE5d1pYSmZjR0ZuWlNJc0luUnBkR3hsSWpvaVhIVTJZbU5tWEhVNU9EYzFYSFUyTmpObFhIVTNPVE5oWEhVMU5tUmxYSFUxT1RCa0lpd2laR1Z6WXlJNklpSXNJbk4wWkNJNklqSXdJaXdpZEhsd1pTSTZJblJsZUhRaWZTeDdJbTVoYldVaU9pSmhibk4zWlhKelgyOXlaR1Z5SWl3aWRHbDBiR1VpT2lKY2RUVTJaR1ZjZFRVNU1HUmNkVFkyTTJWY2RUYzVNMkZjZFRrNE4yRmNkVFZsT0dZaUxDSmtaWE5qSWpvaUlpd2ljM1JrSWpvaUlpd2lkSGx3WlNJNkluTmxiR1ZqZENJc0ltOXdkR2x2Ym5NaU9sc2lYSFUyTXpBNVhIVTJOV1kyWEhVNU5XWTBYSFU1T0RkaFhIVTFaVGhtSWl3aVhIVTJNekE1WEhVMk5XWTJYSFU1TldZMFhIVTFNREV5WEhVMVpUaG1JbDE5TEhzaWJtRnRaU0k2SW5GMVpYTjBhVzl1WDJsdFp5SXNJblJwZEd4bElqb2lYSFU1TldWbFhIVTVPRGs0WEhVMFpUQmhYSFUwWmpJd1hIVTFObVpsWEhVM01qUTNJaXdpWkdWell5STZJbHgxTmpZeVpseDFOVFF5Tmx4MU5URTBNVngxT0dKaU9GeDFObVJtWWx4MU5USmhNRngxT1RWbFpWeDFPVGc1T0Z4MU56WTRORngxTmpWbU5seDFOVEF4T1Z4MU5HVXdZVngxTkdZeU1GeDFOVFptWlZ4MU56STBOeUlzSW5OMFpDSTZJakVpTENKMGVYQmxJam9pZEc5bloyeGxJbjBzZXlKdVlXMWxJam9pWVc1emQyVnlYMmx0WnlJc0luUnBkR3hsSWpvaVhIVTFObVJsWEhVMU9UQmtYSFUwWlRCaFhIVTBaakl3WEhVMU5tWmxYSFUzTWpRM0lpd2laR1Z6WXlJNklseDFOall5Wmx4MU5UUXlObHgxTlRFME1WeDFPR0ppT0Z4MU5UWmtaVngxTlRrd1pGeDFOelk0TkZ4MU5qVm1ObHgxTlRBeE9WeDFOR1V3WVZ4MU5HWXlNRngxTlRabVpWeDFOekkwTnlJc0luTjBaQ0k2SWpFaUxDSjBlWEJsSWpvaWRHOW5aMnhsSW4wc2V5SnVZVzFsSWpvaWJHOW5hVzVmZFhKc0lpd2lkR2wwYkdVaU9pSmNkVGMyTjJKY2RUVm1OVFZjZFRrNE56VmNkVGszTmpJaUxDSmtaWE5qSWpvaVhIVTRZbVkzWEhVNFpqa3pYSFUxTVRZMVhIVTNaalV4WEhVM1lXUTVYSFUzTmpnMFhIVTVaV1E0WEhVNFltRTBYSFUzTmpkaVhIVTFaalUxWEhVNU9EYzFYSFU1TnpZeVhIVTFOek13WEhVMU56UXdJaXdpYzNSa0lqb2lJaXdpZEhsd1pTSTZJblJsZUhRaWZTeDdJbTVoYldVaU9pSnlaV2RwYzNSbGNsOTFjbXdpTENKMGFYUnNaU0k2SWx4MU5tTmxPRngxTlRFNFkxeDFPVGczTlZ4MU9UYzJNaUlzSW1SbGMyTWlPaUpjZFRoaVpqZGNkVGhtT1ROY2RUVXhOalZjZFRkbU5URmNkVGRoWkRsY2RUYzJPRFJjZFRsbFpEaGNkVGhpWVRSY2RUWmpaVGhjZFRVeE9HTmNkVGs0TnpWY2RUazNOakpjZFRVM016QmNkVFUzTkRBaUxDSnpkR1FpT2lJaUxDSjBlWEJsSWpvaWRHVjRkQ0o5TEhzaWJtRnRaU0k2SW1OdmJHOXlJaXdpZEdsMGJHVWlPaUpjZFRsbFpEaGNkVGhpWVRSY2RUazRPV05jZFRneU56SWlMQ0prWlhOaklqb2lYSFU1WldRNFhIVTRZbUUwWEhVNU9EbGpYSFU0TWpjeVhIVm1aakJqWEhVMlltUTBYSFUxT1RneVhIVTJNekE1WEhVNU5HRmxYSFV6TURBeFhIVTVOR1psWEhVMk0yRTFJaXdpYzNSa0lqb2lJekUwTnpGRFFTSXNJblI1Y0dVaU9pSmpiMnh2Y2lKOUxIc2libUZ0WlNJNkltTnZiRzl5WDJodmRtVnlJaXdpZEdsMGJHVWlPaUpjZFRZd1lXTmNkVFprTm1WY2RUazRPV05jZFRneU56SWlMQ0prWlhOaklqb2lYSFU1WmpJd1hIVTJPREEzWEhVMk1HRmpYSFUxTURWalhIVTNOamcwWEhVMk5XWTJYSFUxTURFNVhIVTNOamcwWEhVNU9EbGpYSFU0TWpjeVhIVm1aakJqWEhVMlltUTBYSFUxT1RneVhIVTJNekE1WEhVNU5HRmxYSFV6TURBeFhIVTVOR1psWEhVMk0yRTFJaXdpYzNSa0lqb2lJekJFTmpKQ015SXNJblI1Y0dVaU9pSmpiMnh2Y2lKOUxIc2libUZ0WlNJNkltVnRZV2xzWDI1bGQxOTBhWFJzWlNJc0luUnBkR3hsSWpvaVhIVTJOV0l3WEhVNU5XVmxYSFU1T0RrNFhIVTVNR0ZsWEhVMFpXWTJYSFUyT0RBM1hIVTVPRGs0SWl3aVpHVnpZeUk2SWx4MU5qY3dPVngxTmpWaU1GeDFPVFZsWlZ4MU9UZzVPRngxTlROa01WeDFOV1V3TTF4MU5qVm1ObHgxT1RBeFlWeDFOemRsTlZ4MU9UQmhaVngxTkdWbU5seDFOelk0TkZ4MU5qZ3dOMXgxT1RnNU9GeDFabVl3WTF4MU56VTFPVngxTjJFM1lWeDFOVEl4T1Z4MU5HVXdaRngxTlROa01WeDFPVEF3TVZ4MU9UQmhaVngxTkdWbU5pSXNJbk4wWkNJNklseDFOakJoT0Z4MU56WTRORngxTjJZMU1WeDFOMkZrT1Z4MU5qY3dPVngxTmpWaU1GeDFPVFZsWlZ4MU9UZzVPRngxTlROa01WeDFOV1V3TXlJc0luUjVjR1VpT2lKMFpYaDBJbjBzZXlKdVlXMWxJam9pWlcxaGFXeGZZVzV6ZDJWeVgzUnBkR3hsSWl3aWRHbDBiR1VpT2lKY2RUWTFZakJjZFRVMlpHVmNkVFU1TUdSY2RUa3dZV1ZjZFRSbFpqWmNkVFk0TURkY2RUazRPVGdpTENKa1pYTmpJam9pWEhVMk56QTVYSFUyTldJd1hIVTFObVJsWEhVMU9UQmtYSFUyTldZMlhIVTVNREZoWEhVM04yVTFYSFU1TUdGbFhIVTBaV1kyWEhVM05qZzBYSFUyT0RBM1hIVTVPRGs0WEhWbVpqQmpYSFUzTlRVNVhIVTNZVGRoWEhVMU1qRTVYSFUwWlRCa1hIVTFNMlF4WEhVNU1EQXhYSFU1TUdGbFhIVTBaV1kySWl3aWMzUmtJam9pWEhVMk1HRTRYSFUzTmpnMFhIVTVOV1ZsWEhVNU9EazRYSFUyTnpBNVhIVTBaVGcyWEhVMk5XSXdYSFUxTm1SbFhIVTFPVEJrSWl3aWRIbHdaU0k2SW5SbGVIUWlmU3g3SW01aGJXVWlPaUpsYldGcGJGOWhibk4zWlhKZlkyTWlMQ0owYVhSc1pTSTZJbHgxTmpWaU1GeDFOVFprWlZ4MU5Ua3daRngxT1RCaFpWeDFOR1ZtTmx4MU5qSTRORngxT1RBd01WeDFOMkpoTVZ4MU56UXdObHgxTlRRMU9DSXNJbVJsYzJNaU9pSmNkVFkxWWpCY2RUVTJaR1ZjZFRVNU1HUmNkVGt3WVdWY2RUUmxaalpjZFRrd01XRmNkVGMzWlRWY2RUWTJNbVpjZFRVME1qWmNkVFl5T0RSY2RUa3dNREZjZFRkaVlURmNkVGMwTURaY2RUVTBOVGhjZFRrd1lXVmNkVGRpWWpFaUxDSnpkR1FpT2lJeElpd2lkSGx3WlNJNkluUnZaMmRzWlNKOUxIc2libUZ0WlNJNkluRjFaWE4wYVc5dVgyMXZaR1Z5WVhScGIyNGlMQ0owYVhSc1pTSTZJbHgxT1RWbFpWeDFPVGc1T0Z4MU5XSmhNVngxTmpnek9DSXNJbVJsYzJNaU9pSmNkVFZpWVRGY2RUWTRNemhjZFRnNVl6UmNkVFV5TVRsY2RUUmxZelZjZFRWaVpqbGNkVFkxWlRCY2RUWTFPRGRjZFRkaFpUQmNkVFV6WkRGY2RUVmxNRE5jZFRZM05ETmNkVGsyTlRCY2RUYzJPRFJjZFRjMU1qaGNkVFl5TXpkY2RUWTNNRGxjZFRZMU5EaGNkV1ptTUdOY2RUUm1OV05jZFRnd01EVmNkVFV6WTJGY2RUUmxaVFZjZFRSbE1HRmNkVFkzTkROY2RUazJOVEJjZFRnNVpESmNkVGd5TnpKY2RUWTFaVEJjZFRrM01EQmNkVFZpWVRGY2RUWTRNemdpTENKemRHUWlPaUlpTENKMGVYQmxJam9pYzJWc1pXTjBJaXdpYjNCMGFXOXVjeUk2V3lKY2RUWTFaVEJjZFRrM01EQmNkVFZpWVRGY2RUWTRNemdpTENKY2RUUmxOR0pjZFRVeU5HUmNkVFkzTURsY2RUa3dNV0ZjZFRobVl6ZGNkVFZpWVRGY2RUWTRNemhjZFRjMk9EUmNkVGsxWldWY2RUazRPVGhjZFRVeU1UbGNkVFkxWlRCY2RUazNNREJjZFRWaVlURmNkVFk0TXpnaUxDSmNkVFV4TmpoY2RUa3daVGhjZFRrM01EQmNkVGc1T0RGY2RUVmlZVEZjZFRZNE16Z2lYWDBzZXlKdVlXMWxJam9pWVc1emQyVnlYMjF2WkdWeVlYUnBiMjRpTENKMGFYUnNaU0k2SWx4MU5UWmtaVngxTjJJMU5GeDFOV0poTVZ4MU5qZ3pPQ0lzSW1SbGMyTWlPaUpjZFRWaVlURmNkVFk0TXpoY2RUZzVZelJjZFRVeU1UbGNkVFJsWXpWY2RUVmlaamxjZFRZMVpUQmNkVFkxT0RkY2RUZGhaVEJjZFRVelpERmNkVFZsTUROY2RUWTNORE5jZFRrMk5UQmNkVGMyT0RSY2RUYzFNamhjZFRZeU16ZGNkVFkzTURsY2RUWTFORGhjZFdabU1HTmNkVFJtTldOY2RUZ3dNRFZjZFRVelkyRmNkVFJsWlRWY2RUUmxNR0ZjZFRZM05ETmNkVGsyTlRCY2RUZzVaREpjZFRneU56SmNkVFkxWlRCY2RUazNNREJjZFRWaVlURmNkVFk0TXpnaUxDSnpkR1FpT2lJaUxDSjBlWEJsSWpvaWMyVnNaV04wSWl3aWIzQjBhVzl1Y3lJNld5SmNkVFkxWlRCY2RUazNNREJjZFRWaVlURmNkVFk0TXpnaUxDSmNkVFJsTkdKY2RUVXlOR1JjZFRZM01EbGNkVGt3TVdGY2RUaG1ZemRjZFRWaVlURmNkVFk0TXpoY2RUYzJPRFJjZFRVMlpHVmNkVGRpTlRSY0wxeDFPVFZsWlZ4MU9UZzVPRngxTlRJeE9WeDFOalZsTUZ4MU9UY3dNRngxTldKaE1WeDFOamd6T0NJc0lseDFOVEUyT0Z4MU9UQmxPRngxT1Rjd01GeDFPRGs0TVZ4MU5XSmhNVngxTmpnek9DSmRmVjE5';
            update_option($this->plugin_slug . "_token",'$P$BQUMqlPR7t5ywIplJd7ZtUdCT0uATg/');
			$res = update_option($option_name, $options_data, false );
            if( !$res ){
                global $wpdb;
                $option = $wpdb->get_row( "SELECT * FROM $wpdb->options WHERE option_name = $option_name" );
                if(null !== $option) {
                    $wpdb->update($wpdb->options,
                        array('option_value' => $options_data, 'autoload' => 'no'),
                        array('option_name' => $option_name)
                    );
                }else{
                    $wpdb->query( $wpdb->prepare( "INSERT INTO `$wpdb->options` (`option_name`, `option_value`, `autoload`) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE `option_name` = VALUES(`option_name`), `option_value` = VALUES(`option_value`), `autoload` = VALUES(`autoload`)", $option_name, $options_data, 'no' ) );
                }
            }
			//删除结束
        }
    }

    private function active_form(){
        if(isset($_POST['email'])){
            $email = trim($_POST['email']);
            $token = trim($_POST['token']);
            $err = false;
            if($email==''){
                $err = true;
                $err_email = '登录邮箱不能为空';
            }else if(!is_email( $email )){
                $err = true;
                $err_email = '登录邮箱格式不正确';
            }
            if($token==''){
                $err = true;
                $err_token = '激活码不能为空';
            }else if(strlen($token)!=32){
                $err = true;
                $err_token = '激活码不正确';
            }
            if($err==false){
                $hash_token = wp_hash_password($token);
                update_option( $this->plugin_slug . "_email", $email );
                update_option( $this->plugin_slug . "_token", $hash_token );

                $body = array('email'=>$email, 'token'=>$token, 'version'=>$this->version, 'home'=>get_option('siteurl'), 'themer' => WPCOM_ADMIN_VERSION, 'hash' => $hash_token);
                $result_body = json_decode( $this->send_request('active', $body));
                if( isset($result_body->result) && ($result_body->result=='0'||$result_body->result=='1') ){
                    $active = $result_body;
                    echo '<meta http-equiv="refresh" content="0">';
                }else if(isset($result_body->result)){
                    $active = $result_body;
                }else{
                    $active = new stdClass();
                    $active->result = 10;
                    $active->msg = '激活失败，请稍后再试！';
                }
            }
        }
        ?>
        <form class="form-horizontal active-form" id="wpcom-panel-form" method="post" action="">
            <h2 class="active-title">插件激活</h2>
            <div id="wpcom-panel-main" class="clearfix">
                <div class="form-horizontal">
                    <?php if (isset($active)) { ?><p class="col-xs-offset-3 col-xs-9" style="<?php echo ($active->result==0||$active->result==1?'color:green;':'color:#F33A3A;');?>"><?php echo $active->msg; ?></p><?php } ?>
                    <div class="form-group">
                        <label for="email" class="col-xs-3 control-label">登录邮箱</label>
                        <div class="col-xs-9">
                            <input type="email" name="email" class="form-control" id="email" value="<?php echo isset($email)?$email:''; ?>" placeholder="请输入WPCOM登录邮箱">
                            <?php if(isset($err_email)){ ?><div class="j-msg" style="color:#F33A3A;font-size:12px;margin-top:3px;margin-left:3px;"><?php echo $err_email;?></div><?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="token" class="col-xs-3 control-label">激活码</label>
                        <div class="col-xs-9">
                            <input type="password" name="token" class="form-control" id="token" value="<?php echo isset($token)?$token:'';?>" placeholder="请输入激活码" autocomplete="off">
                            <?php if(isset($err_token)){ ?><div class="j-msg" style="color:#F33A3A;font-size:12px;margin-top:3px;margin-left:3px;"><?php echo $err_token;?></div><?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-xs-3 control-label"></label>
                        <div class="col-xs-9">
                            <input type="submit" class="button button-primary button-active" value="提 交">
                        </div>
                    </div>
                </div>
            </div><!--#wpcom-panel-main-->
        </form>
    <?php }

    private function option_item($option, $i){
        $type = $option->type;
        $title = isset($option->title)?$option->title:'';
        $desc = isset($option->desc)?$option->desc:'';
        $name = isset($option->name)?$option->name:'';
        $id = isset($option->id)?$option->id:$name;
        $rows = isset($option->rows)?$option->rows:3;
        $value = isset($option->std)?$option->std:'';
        $value = isset($this->options[$name]) ? $this->options[$name] : $value;
        $notice = $desc?'<small class="input-notice">'.$desc.'</small>':'';
        $tax = isset($option->tax)?$option->tax:'category';

        switch ($type) {
            case 'title':
                $first = $i==0?' section-hd-first':'';
                echo '<div class="section-hd'.$first.'"><h3 class="section-title">'.$title.' <small>'.$desc.'</small></h3></div>';
                break;

            case 'text':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><input type="text" class="form-control" id="wpcom_'.$id.'" name="'.$name.'" value="'.esc_attr($value).'">'.$notice.'</div></div>';
                break;

            case 'radio':
                $html = '';
                foreach ($option->options as $opk=>$opv) {
                    $opk = $opk==='_empty_'?'':$opk;
                    $opk = $opk===0?'0':$opk;
                    $html.=$opk==$value?'<label class="radio-inline"><input type="radio" name="'.$name.'" checked value="'.$opk.'">'.$opv.'</label>':'<label class="radio-inline"><input type="radio" name="'.$name.'" value="'.$opk.'">'.$opv.'</label>';
                }
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input">'.$html . $notice.'</div></div>';
                break;

            case 'checkbox':
                $html = '';
                foreach ($option->options as $opk=>$opv) {
                    $opk = $opk==='_empty_'?'':$opk;
                    $opk = $opk===0?'0':$opk;
                    $checked = '';
                    if(is_array($value)){
                        foreach($value as $v){
                            if($opk==$v) $checked = ' checked';
                        }
                    }else{
                        if($opk==$value) $checked = ' checked';
                    }
                    $html .= '<label class="checkbox-inline"><input type="checkbox" name="'.$name.'[]"'.$checked.' value="'.$opk.'">'.$opv.'</label>';
                }
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input">'.$html . $notice.'</div></div>';
                break;

            case 'checkbox_sort':
                $html = '';
                $option->options = (array) $option->options;
                $value = $value ? $value : array();
                foreach ($value as $item) {
                    $html.='<label class="checkbox-inline"><input name="'.$name.'[]" checked type="checkbox" value="'.$item.'"> '.$option->options[$item].'</label>';
                }
                foreach ($option->options as $key => $val) {
                    $key = $key==='_empty_'?'':$key;
                    $key = $key===0?'0':$key;
                    if(!in_array($key, $value)){
                        $html.='<label class="checkbox-inline"><input name="'.$name.'[]" type="checkbox" value="'.$key.'"> '.$val.'</label>';
                    }
                }
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><div class="cat-checkbox-list j-cat-sort" data-name="'.$name.'">'.$html.'</div><div>'.$notice.'</div></div></div>';
                break;

            case 'info':
                echo '<div class="form-group clearfix"><label class="form-label">'.$title.'</label><div class="form-input" style="padding-top:7px;">'.$value . $notice.'</div></div>';
                break;

            case 'select':
                $html = '';
                foreach ($option->options as $opk=>$opv) {
                    $opk = $opk==='_empty_'?'':$opk;
                    $opk = $opk===0?'0':$opk;
                    $html.=$opk==$value?'<option selected value="'.$opk.'">'.$opv.'</option>':'<option value="'.$opk.'">'.$opv.'</option>';
                }
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><select class="form-control" id="wpcom_'.$id.'" name="'.$name.'">'.$html.'</select>'.$notice.'</div></div>';
                break;

            case 'textarea':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><textarea class="form-control" rows="'.$rows.'" id="wpcom_'.$id.'" name="'.$name.'">'.esc_html($value).'</textarea>'.$notice.'</div></div>';
                break;

            case 'editor':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="col-sm-10">';
                wp_editor( wpautop( $value ), 'wpcom_'.$id, WPCPM_ADMIN_UTILS::editor_settings(array('textarea_name'=>$name, 'textarea_rows'=>$rows)) );
                echo $notice.'</div></div>';
                break;

            case 'upload':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><input type="text" class="form-control" id="wpcom_'.$id.'" name="'.$name.'" value="'.esc_attr($value).'">'.$notice.'</div><div class="col-sm-2"><button id="wpcom_'.$id.'_upload" type="button" class="button upload-btn"><i class="fa fa-image"></i> 上传</button></div></div>';
                break;

            case 'color':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><input class="color-picker" type="text"  name="'.$name.'" value="'.esc_attr($value).'">'.$notice.'</div></div>';
                break;

            case 'page':
                $html = '<option value="">--请选择--</option>';
                $pages = WPCPM_ADMIN_UTILS::get_all_pages();
                foreach ($pages as $page) {
                    $html.=$page['ID']==$value?'<option selected value="'.$page['ID'].'">'.$page['title'].'</option>':'<option value="'.$page['ID'].'">'.$page['title'].'</option>';
                }
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input"><select class="form-control" id="wpcom_'.$id.'" name="'.$name.'">'.$html.'</select>'.$notice.'</div></div>';
                break;


            case 'cat_single':
                $option->options = WPCPM_ADMIN_UTILS::category($tax);
                $option->type = 'select';
                $this->option_item($option, $i);
                break;

            case 'cat_multi':
                $option->options = WPCPM_ADMIN_UTILS::category($tax);
                $option->type = 'checkbox';
                $this->option_item($option, $i);
                break;

            case 'cat_multi_sort':
                $option->options = WPCPM_ADMIN_UTILS::category($tax);
                $option->type = 'checkbox_sort';
                $this->option_item($option, $i);
                break;

            case 'toggle':
                echo '<div class="form-group clearfix"><label for="wpcom_'.$id.'" class="form-label">'.$title.'</label><div class="form-input toggle-wrap">';
                if($value=='1'){
                    echo '<div class="toggle active"></div>';
                }else{
                    echo '<div class="toggle"></div>';
                }
                echo '<input type="hidden" id="wpcom_'.$id.'" name="'.$name.'" value="'.esc_attr($value).'">'.$notice.'</div></div>';
                break;
            default:
                break;
        }
    }



    function form_action(){
        $nonce = isset($_POST[$this->key . '_nonce']) ? $_POST[$this->key . '_nonce'] : '';

        // Check nonce
        if ( ! $nonce || ! wp_verify_nonce( $nonce, $this->key . '_options' ) ){
            return;
        }

        $data = $_POST;
        $this->options = array();

        if(isset($this->settings->option)) { foreach ($this->settings->option as $item) {
            if(isset($item->name) && $item->name!='' && isset($data[$item->name])) {
                $this->options[$item->name] = $data[$item->name];
            }
        }}

        update_option($this->key, $this->options);
    }

    private function get_settings(){
        $ops = base64_decode(get_option('wpcom_' . $this->info['plugin_id']));
        $token = get_option($this->plugin_slug . "_token");
        $ops = base64_decode(str_replace(md5($token.strtolower($this->plugin_slug)), '', $ops));
        return json_decode($ops);
    }

    private function send_request($type, $body, $method='POST') {
        $url = 'http://www.wpcom.cn/authentication/'.$type.'/' . $this->info['plugin_id'];
        $result = wp_remote_request($url, array('method' => $method, 'body'=>$body));
        if(is_array($result)){
            return $result['body'];
        }
    }

    public function is_active(){
        if(isset($this->is_active) && $this->is_active) return true;
        $this->is_active = false;
        if( !isset($this->settings)) $this->settings = $this->get_settings();
        if( $this->settings && get_option($this->plugin_slug . "_token")) $this->is_active = true;
        return $this->is_active;
    }

    private function plugin_update(){
        global $plugin_updated;
        if(isset($plugin_updated) && $plugin_updated){ // 防多次请求
            return false;
        }else{
            $plugin_updated = 1;
        }
        if( !isset($this->settings)) $this->settings = $this->get_settings();
        if($this->settings){
            $domain = $this->settings->domain;
            $version = $this->settings->version;
            $current_ver = $this->get_version();
            if(is_admin() && version_compare($version, $current_ver)<0){
                $body = array('email'=>get_option($this->plugin_slug . "_email"), 'token'=>get_option($this->plugin_slug . "_token"), 'version'=>$this->version, 'home'=>get_option('siteurl'), 'themer' => $this->framework_version());
                $this->send_request('update', $body);
            }
        }
    }

    private function get_version(){
        if( function_exists('file_get_contents') ){
            $files = @file_get_contents( WP_PLUGIN_DIR . '/' . $this->basename );
            preg_match('/define\s*?\(\s*?[\'|"][^\s]*_VERSION[\'|"],\s*?[\'|"](.*)[\'|"].*?\)/i', $files, $matches);
            if( isset($matches[1]) && $matches[1] ){
                return trim($matches[1]);
            }
        }
        return $this->version;
    }

    private function framework_version(){
        if( function_exists('file_get_contents') ){
            $files = @file_get_contents( WPCOM_ADMIN_PATH . '/load.php' );
            preg_match('/define\s*?\(\s*?[\'|"]WPCOM_ADMIN_VERSION[\'|"],\s*?[\'|"](.*)[\'|"].*?\)/i', $files, $matches);
            if( isset($matches[1]) && $matches[1] ){
                return trim($matches[1]);
            }
        }
        return WPCOM_ADMIN_VERSION;
    }

    public function updated(){
        flush_rewrite_rules();
        delete_option($this->updateName);
        $this->plugin_update();
    }

    public function check_update($value){
        if ($value && empty( $value->checked ) )
            return $value;

        if ( !current_user_can('update_plugins' ) )
            return $value;

        if ( !$this->automaticCheckDone ) {
            $body = array('email' => get_option($this->plugin_slug . "_email"), 'token' => get_option($this->plugin_slug . "_token"), 'version' => $this->version, 'home' => get_option('siteurl'), 'themer' => WPCOM_ADMIN_VERSION);
            $req = $this->send_request('notify', $body);
            $this->automaticCheckDone = true;

            $this->plugin_update();
        }

        global $plugin_update_state;
        if(!isset($plugin_update_state)) $plugin_update_state = get_option($this->updateName);

        if ( !empty($plugin_update_state) && isset($plugin_update_state->update) && !empty($plugin_update_state->update) ){
            $update = $plugin_update_state->update;
            $value->response[$this->basename] = array(
                'slug' => $this->info['slug'],
                'plugin' => $this->info['basename'],
                'new_version' => $update->version,
                'url' => $update->url,
                'package' => $update->package,
                'upgrade_notice' => ''
            );

            $value->response[$this->basename] = json_decode(json_encode($value->response[$this->basename]));
        }

        return $value;
    }
}