<?php
/*
 * Plugin Name: QAPress
 * Plugin URI: https://www.wpcom.cn/plugins/qapress.html
 * Description: WordPress问答功能插件
 * Version: 2.3.1
 *更多资源访问 www.wpzyk.cn
 * Author: WPCOM
 * Author URI: https://www.wpcom.cn
 *Chiser丶
 *https://www.chiser.cc
*/

define( 'QAPress_VERSION', '2.3.1' );
define( 'QAPress_DIR', plugin_dir_path( __FILE__ ) );
define( 'QAPress_URI', plugins_url( '/', __FILE__ ) );

$QAPress_info = array(
    'slug' => 'QAPress',
    'name' => 'QAPress',
    'ver' => QAPress_VERSION,
    'title' => '问答插件',
    'icon' => 'dashicons-editor-help',
    'position' => 30,
    'key' => 'qa_options',
    'plugin_id' => '46b3ade48ebb2b3e',
    'basename' => plugin_basename( __FILE__ )
);

require_once QAPress_DIR . 'admin/load.php';
$GLOBALS['QAPress'] = new WPCOM_PLUGIN_PANEL($QAPress_info);

require_once QAPress_DIR . 'includes/sql.php';
require_once QAPress_DIR . 'includes/html.php';
require_once QAPress_DIR . 'includes/rewrite.php';
require_once QAPress_DIR . 'includes/ajax.php';
require_once QAPress_DIR . 'includes/functions.php';
require_once QAPress_DIR . 'includes/widgets.php';