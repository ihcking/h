<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.

/**
 * 
 * Author URI: http://codestarthemes.com/
 * Version: 2.0.8
 * https://github.com/Codestar/codestar-framework
 * 
 */
 
require_once plugin_dir_path(__FILE__) . 'classes/setup.class.php';
