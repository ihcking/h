ALTER TABLE `pre_pay`
ADD COLUMN `channel` varchar(10) NULL;
