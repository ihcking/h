<?php
$template_info = [
	'name' => '列表简约风格首页模板',
	'version' => 1.0
];

$template_settings = [
	'template_style' => [
		'name'=>'选择界面风格',
		'type'=>'select',
		'options'=> [
			'0'=>'多列',
			'1'=>'单列',
		]
	],
];
