# tiny-heart
## 这是什么
这是一些生日快乐网站的模板，基础是我最开始写的一个。后来有些朋友做了修改，也在这里分享给大家。  

## 如何使用
选择download as zip方式下载或者clone到本地：
```
git clone https://github.com/IcedSoul/tiny-heart
```

## 具体介绍
每个文件夹是一个版本，基本版本是我最开始所做的，也是目前说明文档最为详细的，你可以进入文件夹查看每个版本具体的介绍。

这里放出版本名称和贡献者

作者 | 版本名称 | 风格 | 作者Github  
---|---|---|---
IcedSoul|birthday-basic|粉红/回忆|https://github.com/IcedSoul
weingxing|birthday-brother|蓝色/兄弟|https://github.com/weingxing
weingxing|birthday-mobile|适配移动端|https://github.com/weingxing

## 结束
欢迎star&fork，也欢迎其它贡献者
