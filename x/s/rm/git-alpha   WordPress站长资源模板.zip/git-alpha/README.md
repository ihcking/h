首先，请饶恕我用了这个无比拗口的标题来形容这款主题，因为这就是他的真实写照！

![Git:一款比付费主题更像是付费主题的WordPress免费主题](https://cdn.jsdelivr.net/gh/yunluo/GitCafeApi/IMG/2015051808553935.jpg "Git:一款比付费主题更像是付费主题的WordPress免费主题")

[主题食用说明](https://gitcafe.net/archives/3275.html)

[主题下载](http://a.gitcafe.net/Git-alpha.zip)