<?php
define( 'POINTS_STATUS_PENDING', 'pending' );
define( 'POINTS_STATUS_ACCEPTED', 'accepted' );
define( 'POINTS_STATUS_REJECTED', 'rejected' );
define( 'POINTS_STATUS_REMOVED', 'removed' );
define( 'POINTS_TYPE_USER_REGISTRATION', 'user-registration' );
define( 'POINTS_TYPE_NEW_COMMENT', 'new-comment' );